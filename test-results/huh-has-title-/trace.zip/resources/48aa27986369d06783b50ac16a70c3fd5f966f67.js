/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
// IE11 compat, checks if WeakRef is supported
const _canUseWeakRef = typeof WeakRef !== "undefined";
/**
 * WeakRef wrapper around a HTMLElement that also supports IE11
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakRef}
 * @internal
 */

class WeakRefInstance {
  constructor(instance) {
    if (_canUseWeakRef && typeof instance === "object") {
      this._weakRef = new WeakRef(instance);
    } else {
      this._instance = instance;
    }
  }
  /**
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakRef/deref}
   */


  deref() {
    var _a, _b, _c;

    let instance;

    if (this._weakRef) {
      instance = (_a = this._weakRef) === null || _a === void 0 ? void 0 : _a.deref();

      if (!instance) {
        delete this._weakRef;
      }
    } else {
      instance = this._instance;

      if ((_c = (_b = instance) === null || _b === void 0 ? void 0 : _b.isDisposed) === null || _c === void 0 ? void 0 : _c.call(_b)) {
        delete this._instance;
      }
    }

    return instance;
  }

}

/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const KEYBORG_FOCUSIN = "keyborg:focusin";

function canOverrideNativeFocus(win) {
  const HTMLElement = win.HTMLElement;
  const origFocus = HTMLElement.prototype.focus;
  let isCustomFocusCalled = false;

  HTMLElement.prototype.focus = function focus() {
    isCustomFocusCalled = true;
  };

  const btn = win.document.createElement("button");
  btn.focus();
  HTMLElement.prototype.focus = origFocus;
  return isCustomFocusCalled;
}

let _canOverrideNativeFocus = false;
/**
 * Guarantees that the native `focus` will be used
 */

function nativeFocus(element) {
  const focus = element.focus;

  if (focus.__keyborgNativeFocus) {
    focus.__keyborgNativeFocus.call(element);
  } else {
    element.focus();
  }
}
/**
 * Overrides the native `focus` and setups the keyborg focus event
 */

function setupFocusEvent(win) {
  const kwin = win;

  if (!_canOverrideNativeFocus) {
    _canOverrideNativeFocus = canOverrideNativeFocus(kwin);
  }

  const origFocus = kwin.HTMLElement.prototype.focus;

  if (origFocus.__keyborgNativeFocus) {
    // Already set up.
    return;
  }

  kwin.HTMLElement.prototype.focus = focus;
  const data = kwin.__keyborgData = {
    focusInHandler: e => {
      var _a;

      const target = e.target;

      if (!target) {
        return;
      }

      const event = document.createEvent("HTMLEvents");
      event.initEvent(KEYBORG_FOCUSIN, true, true);
      const details = {
        relatedTarget: e.relatedTarget || undefined
      };

      if (_canOverrideNativeFocus || data.lastFocusedProgrammatically) {
        details.isFocusedProgrammatically = target === ((_a = data.lastFocusedProgrammatically) === null || _a === void 0 ? void 0 : _a.deref());
        data.lastFocusedProgrammatically = undefined;
      }

      event.details = details;
      target.dispatchEvent(event);
    }
  };
  kwin.document.addEventListener("focusin", kwin.__keyborgData.focusInHandler, true);

  function focus() {
    const keyborgNativeFocusEvent = kwin.__keyborgData;

    if (keyborgNativeFocusEvent) {
      keyborgNativeFocusEvent.lastFocusedProgrammatically = new WeakRefInstance(this);
    } // eslint-disable-next-line prefer-rest-params


    return origFocus.apply(this, arguments);
  }

  focus.__keyborgNativeFocus = origFocus;
}
/**
 * Removes keyborg event listeners and custom focus override
 * @param win The window that stores keyborg focus events
 */

function disposeFocusEvent(win) {
  const kwin = win;
  const proto = kwin.HTMLElement.prototype;
  const origFocus = proto.focus.__keyborgNativeFocus;
  const keyborgNativeFocusEvent = kwin.__keyborgData;

  if (keyborgNativeFocusEvent) {
    kwin.document.removeEventListener("focusin", keyborgNativeFocusEvent.focusInHandler, true);
    delete kwin.__keyborgData;
  }

  if (origFocus) {
    proto.focus = origFocus;
  }
}
/**
 * @param win The window that stores keyborg focus events
 * @returns The last element focused with element.focus()
 */

function getLastFocusedProgrammatically(win) {
  var _a;

  const keyborgNativeFocusEvent = win.__keyborgData;
  return keyborgNativeFocusEvent ? ((_a = keyborgNativeFocusEvent.lastFocusedProgrammatically) === null || _a === void 0 ? void 0 : _a.deref()) || null : undefined;
}

/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const _dismissTimeout = 500; // When a key from dismissKeys is pressed and the focus is not moved
// during _dismissTimeout time, dismiss the keyboard navigation mode.

let _lastId = 0;
/**
 * Source of truth for all the keyborg core instances and the current keyboard navigation state
 */

class KeyborgState {
  constructor() {
    this.__keyborgCoreRefs = {};
    this._isNavigatingWithKeyboard = false;
  }

  add(keyborg) {
    const id = keyborg.id;

    if (!(id in this.__keyborgCoreRefs)) {
      this.__keyborgCoreRefs[id] = new WeakRefInstance(keyborg);
    }
  }

  remove(id) {
    delete this.__keyborgCoreRefs[id];

    if (Object.keys(this.__keyborgCoreRefs).length === 0) {
      this._isNavigatingWithKeyboard = false;
    }
  }

  setVal(isNavigatingWithKeyboard) {
    if (this._isNavigatingWithKeyboard === isNavigatingWithKeyboard) {
      return;
    }

    this._isNavigatingWithKeyboard = isNavigatingWithKeyboard;

    for (const id of Object.keys(this.__keyborgCoreRefs)) {
      const ref = this.__keyborgCoreRefs[id];
      const keyborg = ref.deref();

      if (keyborg) {
        keyborg.update(isNavigatingWithKeyboard);
      } else {
        this.remove(id);
      }
    }
  }

  getVal() {
    return this._isNavigatingWithKeyboard;
  }

}

const _state = /*#__PURE__*/new KeyborgState();
/**
 * Manages a collection of Keyborg instances in a window/document and updates keyborg state
 */


class KeyborgCore {
  constructor(win, props) {
    this._isMouseUsed = false;

    this._onFocusIn = e => {
      if (this._isMouseUsed) {
        this._isMouseUsed = false;
        return;
      }

      if (_state.getVal()) {
        return;
      }

      const details = e.details;

      if (!details.relatedTarget) {
        return;
      }

      if (details.isFocusedProgrammatically || details.isFocusedProgrammatically === undefined) {
        // The element is focused programmatically, or the programmatic focus detection
        // is not working.
        return;
      }

      _state.setVal(true);
    };

    this._onMouseDown = e => {
      if (e.buttons === 0 || e.clientX === 0 && e.clientY === 0 && e.screenX === 0 && e.screenY === 0) {
        // This is most likely an event triggered by the screen reader to perform
        // an action on an element, do not dismiss the keyboard navigation mode.
        return;
      }

      this._isMouseUsed = true;

      _state.setVal(false);
    };

    this._onKeyDown = e => {
      var _a;

      const isNavigatingWithKeyboard = _state.getVal();

      const keyCode = e.keyCode;
      const triggerKeys = this._triggerKeys;

      if (!isNavigatingWithKeyboard && (!triggerKeys || triggerKeys.has(keyCode))) {
        _state.setVal(true);
      } else if (isNavigatingWithKeyboard && ((_a = this._dismissKeys) === null || _a === void 0 ? void 0 : _a.has(keyCode))) {
        this._scheduleDismiss();
      }
    };

    this.id = "c" + ++_lastId;
    this._win = win;
    const doc = win.document;

    if (props) {
      const triggerKeys = props.triggerKeys;
      const dismissKeys = props.dismissKeys;

      if (triggerKeys === null || triggerKeys === void 0 ? void 0 : triggerKeys.length) {
        this._triggerKeys = new Set(triggerKeys);
      }

      if (dismissKeys === null || dismissKeys === void 0 ? void 0 : dismissKeys.length) {
        this._dismissKeys = new Set(dismissKeys);
      }
    }

    doc.addEventListener(KEYBORG_FOCUSIN, this._onFocusIn, true); // Capture!

    doc.addEventListener("mousedown", this._onMouseDown, true); // Capture!

    win.addEventListener("keydown", this._onKeyDown, true); // Capture!

    setupFocusEvent(win);

    _state.add(this);
  }

  dispose() {
    const win = this._win;

    if (win) {
      if (this._dismissTimer) {
        win.clearTimeout(this._dismissTimer);
        this._dismissTimer = undefined;
      }

      disposeFocusEvent(win);
      const doc = win.document;
      doc.removeEventListener(KEYBORG_FOCUSIN, this._onFocusIn, true); // Capture!

      doc.removeEventListener("mousedown", this._onMouseDown, true); // Capture!

      win.removeEventListener("keydown", this._onKeyDown, true); // Capture!

      delete this._win;

      _state.remove(this.id);
    }
  }

  isDisposed() {
    return !!this._win;
  }
  /**
   * Updates all keyborg instances with the keyboard navigation state
   */


  update(isNavigatingWithKeyboard) {
    var _a, _b;

    const keyborgs = (_b = (_a = this._win) === null || _a === void 0 ? void 0 : _a.__keyborg) === null || _b === void 0 ? void 0 : _b.refs;

    if (keyborgs) {
      for (const id of Object.keys(keyborgs)) {
        Keyborg.update(keyborgs[id], isNavigatingWithKeyboard);
      }
    }
  }

  _scheduleDismiss() {
    const win = this._win;

    if (win) {
      if (this._dismissTimer) {
        win.clearTimeout(this._dismissTimer);
        this._dismissTimer = undefined;
      }

      const was = win.document.activeElement;
      this._dismissTimer = win.setTimeout(() => {
        this._dismissTimer = undefined;
        const cur = win.document.activeElement;

        if (was && cur && was === cur) {
          // Esc was pressed, currently focused element hasn't changed.
          // Just dismiss the keyboard navigation mode.
          _state.setVal(false);
        }
      }, _dismissTimeout);
    }
  }

}
/**
 * Used to determine the keyboard navigation state
 */


class Keyborg {
  constructor(win, props) {
    this._cb = [];
    this._id = "k" + ++_lastId;
    this._win = win;
    const current = win.__keyborg;

    if (current) {
      this._core = current.core;
      current.refs[this._id] = this;
    } else {
      this._core = new KeyborgCore(win, props);
      win.__keyborg = {
        core: this._core,
        refs: {
          [this._id]: this
        }
      };
    }
  }

  static create(win, props) {
    return new Keyborg(win, props);
  }

  static dispose(instance) {
    instance.dispose();
  }
  /**
   * Updates all subscribed callbacks with the keyboard navigation state
   */


  static update(instance, isNavigatingWithKeyboard) {
    instance._cb.forEach(callback => callback(isNavigatingWithKeyboard));
  }

  dispose() {
    var _a;

    const current = (_a = this._win) === null || _a === void 0 ? void 0 : _a.__keyborg;

    if (current === null || current === void 0 ? void 0 : current.refs[this._id]) {
      delete current.refs[this._id];

      if (Object.keys(current.refs).length === 0) {
        current.core.dispose(); // eslint-disable-next-line @typescript-eslint/no-non-null-assertion

        delete this._win.__keyborg;
      }
    } else if (process.env.NODE_ENV === 'development') {
      console.error("Keyborg instance " + this._id + " is being disposed incorrectly.");
    }

    this._cb = [];
    delete this._core;
    delete this._win;
  }
  /**
   * @returns Whether the user is navigating with keyboard
   */


  isNavigatingWithKeyboard() {
    return _state.getVal();
  }
  /**
   * @param callback - Called when the keyboard navigation state changes
   */


  subscribe(callback) {
    this._cb.push(callback);
  }
  /**
   * @param callback - Registered with subscribe
   */


  unsubscribe(callback) {
    const index = this._cb.indexOf(callback);

    if (index >= 0) {
      this._cb.splice(index, 1);
    }
  }
  /**
   * Manually set the keyboard navigtion state
   */


  setVal(isNavigatingWithKeyboard) {
    _state.setVal(isNavigatingWithKeyboard);
  }

}
function createKeyborg(win, props) {
  return Keyborg.create(win, props);
}
function disposeKeyborg(instance) {
  Keyborg.dispose(instance);
}

/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
const version = "2.0.0";

export { KEYBORG_FOCUSIN, Keyborg, createKeyborg, disposeKeyborg, getLastFocusedProgrammatically, nativeFocus, version };
//# sourceMappingURL=keyborg.esm.js.map
